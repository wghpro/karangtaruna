'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { 
  Users, 
  Baby, 
  CheckCircle, 
  Clock, 
  XCircle, 
  Search,
  LogOut,
  Home,
  Settings,
  FileText,
  TrendingUp,
  Calendar
} from 'lucide-react'

interface Pendaftaran {
  id: string
  tahunAjaran: string
  status: 'menunggu' | 'diterima' | 'ditolak'
  catatan?: string
  tanggalDaftar: string
  user: {
    id: string
    name: string
    email: string
    phone: string
  }
  siswa: {
    id: string
    namaLengkap: string
    namaPanggilan: string
    tanggalLahir: string
    jenisKelamin: string
    orangTua: {
      namaAyah: string
      namaIbu: string
      noHpAyah: string
      noHpIbu: string
    }
  }
}

export default function AdminDashboard() {
  const [pendaftaranList, setPendaftaranList] = useState<Pendaftaran[]>([])
  const [filteredPendaftaran, setFilteredPendaftaran] = useState<Pendaftaran[]>([])
  const [stats, setStats] = useState({
    total: 0,
    menunggu: 0,
    diterima: 0,
    ditolak: 0
  })
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [selectedPendaftaran, setSelectedPendaftaran] = useState<Pendaftaran | null>(null)
  const [catatan, setCatatan] = useState('')
  const [isLoading, setIsLoading] = useState(true)
  const [isUpdating, setIsUpdating] = useState(false)
  const router = useRouter()

  useEffect(() => {
    // Check authentication
    const token = localStorage.getItem('token')
    const user = localStorage.getItem('user')
    
    if (!token || !user) {
      router.push('/login')
      return
    }

    const userData = JSON.parse(user)
    if (userData.role !== 'admin') {
      router.push('/user/dashboard')
      return
    }

    fetchPendaftaran()
  }, [router])

  useEffect(() => {
    // Filter data based on search and status
    let filtered = pendaftaranList

    if (searchTerm) {
      filtered = filtered.filter(p => 
        p.siswa.namaLengkap.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.user.email.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter(p => p.status === statusFilter)
    }

    setFilteredPendaftaran(filtered)
  }, [pendaftaranList, searchTerm, statusFilter])

  const fetchPendaftaran = async () => {
    try {
      const token = localStorage.getItem('token')
      const response = await fetch('/api/admin/pendaftaran', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setPendaftaranList(data)
        
        // Calculate stats
        const newStats = {
          total: data.length,
          menunggu: data.filter((p: Pendaftaran) => p.status === 'menunggu').length,
          diterima: data.filter((p: Pendaftaran) => p.status === 'diterima').length,
          ditolak: data.filter((p: Pendaftaran) => p.status === 'ditolak').length
        }
        setStats(newStats)
      }
    } catch (error) {
      console.error('Error fetching pendaftaran:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleUpdateStatus = async (pendaftaranId: string, newStatus: string) => {
    setIsUpdating(true)
    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/admin/pendaftaran/${pendaftaranId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          status: newStatus,
          catatan: catatan
        })
      })

      if (response.ok) {
        await fetchPendaftaran()
        setSelectedPendaftaran(null)
        setCatatan('')
      }
    } catch (error) {
      console.error('Error updating status:', error)
    } finally {
      setIsUpdating(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    router.push('/login')
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'menunggu':
        return <Badge variant="secondary"><Clock className="w-3 h-3 mr-1" />Menunggu</Badge>
      case 'diterima':
        return <Badge className="bg-green-500"><CheckCircle className="w-3 h-3 mr-1" />Diterima</Badge>
      case 'ditolak':
        return <Badge variant="destructive"><XCircle className="w-3 h-3 mr-1" />Ditolak</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Memuat data...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <Link href="/" className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
                  <Baby className="w-5 h-5 text-white" />
                </div>
                <h1 className="text-xl font-bold text-gray-800">PAUD Ceria</h1>
              </Link>
              <nav className="hidden md:flex space-x-4">
                <Link href="/admin/dashboard" className="text-orange-600 font-medium">Dashboard</Link>
                <Link href="/admin/siswa" className="text-gray-600 hover:text-orange-600">Data Siswa</Link>
                <Link href="/admin/settings" className="text-gray-600 hover:text-orange-600">Pengaturan</Link>
              </nav>
            </div>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="w-4 h-4 mr-2" />
              Keluar
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Page Title */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-800">Dashboard Administrator</h2>
          <p className="text-gray-600">Kelola pendaftaran siswa PAUD Ceria</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Pendaftar</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total}</div>
              <p className="text-xs text-muted-foreground">Semua pendaftar</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Menunggu</CardTitle>
              <Clock className="h-4 w-4 text-orange-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">{stats.menunggu}</div>
              <p className="text-xs text-muted-foreground">Perlu verifikasi</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Diterima</CardTitle>
              <CheckCircle className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{stats.diterima}</div>
              <p className="text-xs text-muted-foreground">Siswa diterima</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Ditolak</CardTitle>
              <XCircle className="h-4 w-4 text-red-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{stats.ditolak}</div>
              <p className="text-xs text-muted-foreground">Pendaftar ditolak</p>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Filter Pendaftaran</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="search">Cari Nama atau Email</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="search"
                    placeholder="Cari..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="status">Status</Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Semua Status</SelectItem>
                    <SelectItem value="menunggu">Menunggu</SelectItem>
                    <SelectItem value="diterima">Diterima</SelectItem>
                    <SelectItem value="ditolak">Ditolak</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Pendaftaran Table */}
        <Card>
          <CardHeader>
            <CardTitle>Data Pendaftaran</CardTitle>
            <CardDescription>
              Daftar semua pendaftaran siswa baru
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Tanggal</TableHead>
                    <TableHead>Nama Siswa</TableHead>
                    <TableHead>Orang Tua</TableHead>
                    <TableHead>Kontak</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPendaftaran.map((pendaftaran) => (
                    <TableRow key={pendaftaran.id}>
                      <TableCell>
                        {new Date(pendaftaran.tanggalDaftar).toLocaleDateString('id-ID')}
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{pendaftaran.siswa.namaLengkap}</div>
                          <div className="text-sm text-gray-500">{pendaftaran.siswa.namaPanggilan}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="text-sm">{pendaftaran.user.name}</div>
                          <div className="text-xs text-gray-500">
                            Ayah: {pendaftaran.siswa.orangTua.namaAyah}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div>{pendaftaran.user.phone}</div>
                          <div className="text-xs text-gray-500">{pendaftaran.user.email}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        {getStatusBadge(pendaftaran.status)}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedPendaftaran(pendaftaran)}
                        >
                          Detail
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detail Modal */}
      {selectedPendaftaran && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-xl font-bold">Detail Pendaftaran</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedPendaftaran(null)}
                >
                  ×
                </Button>
              </div>

              <div className="space-y-4">
                {/* Data Siswa */}
                <div>
                  <h4 className="font-semibold mb-2">Data Siswa</h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div><strong>Nama Lengkap:</strong> {selectedPendaftaran.siswa.namaLengkap}</div>
                    <div><strong>Nama Panggilan:</strong> {selectedPendaftaran.siswa.namaPanggilan}</div>
                    <div><strong>Tanggal Lahir:</strong> {new Date(selectedPendaftaran.siswa.tanggalLahir).toLocaleDateString('id-ID')}</div>
                    <div><strong>Jenis Kelamin:</strong> {selectedPendaftaran.siswa.jenisKelamin === 'L' ? 'Laki-laki' : 'Perempuan'}</div>
                  </div>
                </div>

                {/* Data Orang Tua */}
                <div>
                  <h4 className="font-semibold mb-2">Data Orang Tua</h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div><strong>Nama Ayah:</strong> {selectedPendaftaran.siswa.orangTua.namaAyah}</div>
                    <div><strong>Nama Ibu:</strong> {selectedPendaftaran.siswa.orangTua.namaIbu}</div>
                    <div><strong>HP Ayah:</strong> {selectedPendaftaran.siswa.orangTua.noHpAyah}</div>
                    <div><strong>HP Ibu:</strong> {selectedPendaftaran.siswa.orangTua.noHpIbu}</div>
                  </div>
                </div>

                {/* Data Pendaftar */}
                <div>
                  <h4 className="font-semibold mb-2">Data Pendaftar</h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div><strong>Nama:</strong> {selectedPendaftaran.user.name}</div>
                    <div><strong>Email:</strong> {selectedPendaftaran.user.email}</div>
                    <div><strong>Telepon:</strong> {selectedPendaftaran.user.phone}</div>
                    <div><strong>Tahun Ajaran:</strong> {selectedPendaftaran.tahunAjaran}</div>
                  </div>
                </div>

                {/* Status Update */}
                <div>
                  <h4 className="font-semibold mb-2">Update Status</h4>
                  <div className="space-y-2">
                    <div>
                      <Label>Status Saat Ini: {getStatusBadge(selectedPendaftaran.status)}</Label>
                    </div>
                    <div>
                      <Label htmlFor="catatan">Catatan</Label>
                      <Input
                        id="catatan"
                        placeholder="Tambahkan catatan (opsional)"
                        value={catatan}
                        onChange={(e) => setCatatan(e.target.value)}
                      />
                    </div>
                    <div className="flex space-x-2">
                      {selectedPendaftaran.status === 'menunggu' && (
                        <>
                          <Button
                            onClick={() => handleUpdateStatus(selectedPendaftaran.id, 'diterima')}
                            disabled={isUpdating}
                            className="bg-green-500 hover:bg-green-600"
                          >
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Terima
                          </Button>
                          <Button
                            onClick={() => handleUpdateStatus(selectedPendaftaran.id, 'ditolak')}
                            disabled={isUpdating}
                            variant="destructive"
                          >
                            <XCircle className="w-4 h-4 mr-2" />
                            Tolak
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
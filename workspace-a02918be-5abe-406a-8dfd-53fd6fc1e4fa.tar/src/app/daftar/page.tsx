'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { Baby, Eye, EyeOff, User, Users, Calendar, MapPin, Phone } from 'lucide-react'

interface FormData {
  // Data User
  name: string
  email: string
  password: string
  confirmPassword: string
  phone: string
  address: string
  
  // Data Orang Tua
  namaAyah: string
  namaIbu: string
  pekerjaanAyah: string
  pekerjaanIbu: string
  noHpAyah: string
  noHpIbu: string
  
  // Data Siswa
  namaLengkap: string
  namaPanggilan: string
  tempatLahir: string
  tanggalLahir: string
  jenisKelamin: string
  agama: string
  anakKe: string
  jumlahSaudara: string
  bahasaRumah: string
  
  // Data Pendaftaran
  tahunAjaran: string
  
  // Agreement
  agreement: boolean
}

export default function DaftarPage() {
  const [formData, setFormData] = useState<FormData>({
    // Data User
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',
    address: '',
    
    // Data Orang Tua
    namaAyah: '',
    namaIbu: '',
    pekerjaanAyah: '',
    pekerjaanIbu: '',
    noHpAyah: '',
    noHpIbu: '',
    
    // Data Siswa
    namaLengkap: '',
    namaPanggilan: '',
    tempatLahir: '',
    tanggalLahir: '',
    jenisKelamin: '',
    agama: '',
    anakKe: '',
    jumlahSaudara: '',
    bahasaRumah: '',
    
    // Data Pendaftaran
    tahunAjaran: '2024/2025',
    
    // Agreement
    agreement: false
  })

  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const [currentStep, setCurrentStep] = useState(1)
  const router = useRouter()

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target
    
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const validateStep = (step: number) => {
    switch (step) {
      case 1:
        if (!formData.name || !formData.email || !formData.password || !formData.confirmPassword) {
          setError('Semua field harus diisi')
          return false
        }
        if (formData.password !== formData.confirmPassword) {
          setError('Password dan konfirmasi password harus sama')
          return false
        }
        if (formData.password.length < 6) {
          setError('Password minimal 6 karakter')
          return false
        }
        break
      case 2:
        if (!formData.namaAyah || !formData.namaIbu || !formData.noHpAyah || !formData.noHpIbu) {
          setError('Data orang tua lengkap harus diisi')
          return false
        }
        break
      case 3:
        if (!formData.namaLengkap || !formData.tanggalLahir || !formData.jenisKelamin) {
          setError('Data siswa lengkap harus diisi')
          return false
        }
        break
      case 4:
        if (!formData.agreement) {
          setError('Anda harus menyetujui syarat dan ketentuan')
          return false
        }
        break
    }
    setError('')
    return true
  }

  const nextStep = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => Math.min(prev + 1, 4))
    }
  }

  const prevStep = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!validateStep(currentStep)) {
      return
    }

    setIsLoading(true)
    setError('')

    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })

      const data = await response.json()

      if (response.ok) {
        router.push('/login?message=registrasi-berhasil')
      } else {
        setError(data.message || 'Pendaftaran gagal. Silakan coba lagi.')
      }
    } catch (err) {
      setError('Terjadi kesalahan. Silakan coba lagi.')
    } finally {
      setIsLoading(false)
    }
  }

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Data Akun</h3>
            
            <div>
              <Label htmlFor="name">Nama Lengkap</Label>
              <Input
                id="name"
                name="name"
                placeholder="Masukkan nama lengkap Anda"
                value={formData.name}
                onChange={handleChange}
                required
              />
            </div>

            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder="nama@email.com"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>

            <div>
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Minimal 6 karakter"
                  value={formData.password}
                  onChange={handleChange}
                  required
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>

            <div>
              <Label htmlFor="confirmPassword">Konfirmasi Password</Label>
              <div className="relative">
                <Input
                  id="confirmPassword"
                  name="confirmPassword"
                  type={showConfirmPassword ? 'text' : 'password'}
                  placeholder="Ulangi password"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  required
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                >
                  {showConfirmPassword ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>

            <div>
              <Label htmlFor="phone">No. Telepon</Label>
              <Input
                id="phone"
                name="phone"
                placeholder="08123456789"
                value={formData.phone}
                onChange={handleChange}
              />
            </div>

            <div>
              <Label htmlFor="address">Alamat</Label>
              <Input
                id="address"
                name="address"
                placeholder="Masukkan alamat lengkap"
                value={formData.address}
                onChange={handleChange}
              />
            </div>
          </div>
        )

      case 2:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Data Orang Tua/Wali</h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="namaAyah">Nama Ayah</Label>
                <Input
                  id="namaAyah"
                  name="namaAyah"
                  placeholder="Nama ayah"
                  value={formData.namaAyah}
                  onChange={handleChange}
                  required
                />
              </div>
              <div>
                <Label htmlFor="namaIbu">Nama Ibu</Label>
                <Input
                  id="namaIbu"
                  name="namaIbu"
                  placeholder="Nama ibu"
                  value={formData.namaIbu}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="pekerjaanAyah">Pekerjaan Ayah</Label>
                <Input
                  id="pekerjaanAyah"
                  name="pekerjaanAyah"
                  placeholder="Pekerjaan ayah"
                  value={formData.pekerjaanAyah}
                  onChange={handleChange}
                />
              </div>
              <div>
                <Label htmlFor="pekerjaanIbu">Pekerjaan Ibu</Label>
                <Input
                  id="pekerjaanIbu"
                  name="pekerjaanIbu"
                  placeholder="Pekerjaan ibu"
                  value={formData.pekerjaanIbu}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="noHpAyah">No. HP Ayah</Label>
                <Input
                  id="noHpAyah"
                  name="noHpAyah"
                  placeholder="08123456789"
                  value={formData.noHpAyah}
                  onChange={handleChange}
                  required
                />
              </div>
              <div>
                <Label htmlFor="noHpIbu">No. HP Ibu</Label>
                <Input
                  id="noHpIbu"
                  name="noHpIbu"
                  placeholder="08123456789"
                  value={formData.noHpIbu}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>
          </div>
        )

      case 3:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Data Calon Siswa</h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="namaLengkap">Nama Lengkap</Label>
                <Input
                  id="namaLengkap"
                  name="namaLengkap"
                  placeholder="Nama lengkap anak"
                  value={formData.namaLengkap}
                  onChange={handleChange}
                  required
                />
              </div>
              <div>
                <Label htmlFor="namaPanggilan">Nama Panggilan</Label>
                <Input
                  id="namaPanggilan"
                  name="namaPanggilan"
                  placeholder="Nama panggilan anak"
                  value={formData.namaPanggilan}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="tempatLahir">Tempat Lahir</Label>
                <Input
                  id="tempatLahir"
                  name="tempatLahir"
                  placeholder="Kota kelahiran"
                  value={formData.tempatLahir}
                  onChange={handleChange}
                />
              </div>
              <div>
                <Label htmlFor="tanggalLahir">Tanggal Lahir</Label>
                <Input
                  id="tanggalLahir"
                  name="tanggalLahir"
                  type="date"
                  value={formData.tanggalLahir}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Jenis Kelamin</Label>
                <Select value={formData.jenisKelamin} onValueChange={(value) => handleSelectChange('jenisKelamin', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih jenis kelamin" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="L">Laki-laki</SelectItem>
                    <SelectItem value="P">Perempuan</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Agama</Label>
                <Select value={formData.agama} onValueChange={(value) => handleSelectChange('agama', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih agama" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Islam">Islam</SelectItem>
                    <SelectItem value="Kristen">Kristen</SelectItem>
                    <SelectItem value="Katolik">Katolik</SelectItem>
                    <SelectItem value="Hindu">Hindu</SelectItem>
                    <SelectItem value="Buddha">Buddha</SelectItem>
                    <SelectItem value="Konghucu">Konghucu</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="anakKe">Anak Ke</Label>
                <Input
                  id="anakKe"
                  name="anakKe"
                  type="number"
                  placeholder="1"
                  min="1"
                  value={formData.anakKe}
                  onChange={handleChange}
                />
              </div>
              <div>
                <Label htmlFor="jumlahSaudara">Jumlah Saudara</Label>
                <Input
                  id="jumlahSaudara"
                  name="jumlahSaudara"
                  type="number"
                  placeholder="0"
                  min="0"
                  value={formData.jumlahSaudara}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div>
              <Label>Bahasa yang Digunakan di Rumah</Label>
              <Select value={formData.bahasaRumah} onValueChange={(value) => handleSelectChange('bahasaRumah', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Pilih bahasa" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Indonesia">Bahasa Indonesia</SelectItem>
                  <SelectItem value="Inggris">Bahasa Inggris</SelectItem>
                  <SelectItem value="Mandarin">Bahasa Mandarin</SelectItem>
                  <SelectItem value="Lainnya">Lainnya</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Tahun Ajaran</Label>
              <Select value={formData.tahunAjaran} onValueChange={(value) => handleSelectChange('tahunAjaran', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Pilih tahun ajaran" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2024/2025">2024/2025</SelectItem>
                  <SelectItem value="2025/2026">2025/2026</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        )

      case 4:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Konfirmasi & Persetujuan</h3>
            
            <div className="bg-gray-50 p-4 rounded-lg space-y-2">
              <h4 className="font-semibold">Ringkasan Data:</h4>
              <div className="text-sm space-y-1">
                <p><strong>Nama:</strong> {formData.name}</p>
                <p><strong>Email:</strong> {formData.email}</p>
                <p><strong>Telepon:</strong> {formData.phone}</p>
                <p><strong>Nama Ayah:</strong> {formData.namaAyah}</p>
                <p><strong>Nama Ibu:</strong> {formData.namaIbu}</p>
                <p><strong>Nama Siswa:</strong> {formData.namaLengkap}</p>
                <p><strong>Tanggal Lahir:</strong> {formData.tanggalLahir}</p>
                <p><strong>Tahun Ajaran:</strong> {formData.tahunAjaran}</p>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-start space-x-2">
                <Checkbox
                  id="agreement"
                  checked={formData.agreement}
                  onCheckedChange={(checked) => 
                    setFormData(prev => ({ ...prev, agreement: checked as boolean }))
                  }
                />
                <Label htmlFor="agreement" className="text-sm">
                  Saya menyatakan bahwa data yang diisi adalah benar dan bersedia 
                  mematuhi semua peraturan yang berlaku di PAUD Ceria.
                </Label>
              </div>
            </div>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-pink-50 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Baby className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">PAUD Ceria</h1>
          <p className="text-gray-600">Formulir Pendaftaran Siswa Baru</p>
        </div>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {[1, 2, 3, 4].map((step) => (
              <div key={step} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  currentStep >= step ? 'bg-orange-500 text-white' : 'bg-gray-200 text-gray-600'
                }`}>
                  {step}
                </div>
                {step < 4 && (
                  <div className={`w-full h-1 mx-2 ${
                    currentStep > step ? 'bg-orange-500' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-2 text-xs text-gray-600">
            <span>Akun</span>
            <span>Orang Tua</span>
            <span>Data Siswa</span>
            <span>Konfirmasi</span>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>
              Langkah {currentStep} dari 4
            </CardTitle>
            <CardDescription>
              {currentStep === 1 && "Buat akun untuk orang tua/wali"}
              {currentStep === 2 && "Lengkapi data orang tua/wali"}
              {currentStep === 3 && "Masukkan data calon siswa"}
              {currentStep === 4 && "Periksa kembali dan setujui syarat"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {error && (
              <Alert variant="destructive" className="mb-4">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit}>
              {renderStep()}

              <div className="flex justify-between mt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={prevStep}
                  disabled={currentStep === 1}
                >
                  Sebelumnya
                </Button>

                {currentStep < 4 ? (
                  <Button type="button" onClick={nextStep}>
                    Selanjutnya
                  </Button>
                ) : (
                  <Button 
                    type="submit" 
                    className="bg-orange-500 hover:bg-orange-600"
                    disabled={isLoading}
                  >
                    {isLoading ? 'Memproses...' : 'Daftar Sekarang'}
                  </Button>
                )}
              </div>
            </form>
          </CardContent>
        </Card>

        <div className="text-center mt-6">
          <p className="text-sm text-gray-600">
            Sudah punya akun?{' '}
            <Link href="/login" className="text-orange-500 hover:underline">
              Masuk di sini
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
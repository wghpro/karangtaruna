'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  Baby, 
  CheckCircle, 
  Clock, 
  XCircle, 
  LogOut,
  Home,
  User,
  FileText,
  Plus,
  Calendar,
  Phone,
  Mail
} from 'lucide-react'

interface Pendaftaran {
  id: string
  tahunAjaran: string
  status: 'menunggu' | 'diterima' | 'ditolak'
  catatan?: string
  tanggalDaftar: string
  siswa: {
    id: string
    namaLengkap: string
    namaPanggilan: string
    tanggalLahir: string
    jenisKelamin: string
    tempatLahir: string
    agama: string
    anakKe?: number
    jumlahSaudara?: number
    bahasaRumah: string
    orangTua: {
      namaAyah: string
      namaIbu: string
      pekerjaanAyah?: string
      pekerjaanIbu?: string
      noHpAyah: string
      noHpIbu: string
      alamat?: string
    }
  }
}

export default function UserDashboard() {
  const [pendaftaranList, setPendaftaranList] = useState<Pendaftaran[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    // Check authentication
    const token = localStorage.getItem('token')
    const userData = localStorage.getItem('user')
    
    if (!token || !userData) {
      router.push('/login')
      return
    }

    const parsedUser = JSON.parse(userData)
    if (parsedUser.role === 'admin') {
      router.push('/admin/dashboard')
      return
    }

    setUser(parsedUser)
    fetchPendaftaran()
  }, [router])

  const fetchPendaftaran = async () => {
    try {
      const token = localStorage.getItem('token')
      const response = await fetch('/api/user/pendaftaran', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setPendaftaranList(data)
      }
    } catch (error) {
      console.error('Error fetching pendaftaran:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    router.push('/login')
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'menunggu':
        return <Badge variant="secondary"><Clock className="w-3 h-3 mr-1" />Menunggu Verifikasi</Badge>
      case 'diterima':
        return <Badge className="bg-green-500"><CheckCircle className="w-3 h-3 mr-1" />Diterima</Badge>
      case 'ditolak':
        return <Badge variant="destructive"><XCircle className="w-3 h-3 mr-1" />Ditolak</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  const getStatusMessage = (status: string) => {
    switch (status) {
      case 'menunggu':
        return 'Pendaftaran Anda sedang dalam proses verifikasi oleh tim PAUD Ceria. Proses ini biasanya memakan waktu 1-3 hari kerja.'
      case 'diterima':
        return 'Selamat! Pendaftaran anak Anda telah diterima. Tim kami akan segera menghubungi Anda untuk informasi selanjutnya.'
      case 'ditolak':
        return 'Maaf, pendaftaran anak Anda belum dapat diterima pada tahun ajaran ini. Silakan hubungi kami untuk informasi lebih lanjut.'
      default:
        return ''
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Memuat data...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <Link href="/" className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
                  <Baby className="w-5 h-5 text-white" />
                </div>
                <h1 className="text-xl font-bold text-gray-800">PAUD Ceria</h1>
              </Link>
              <nav className="hidden md:flex space-x-4">
                <Link href="/user/dashboard" className="text-orange-600 font-medium">Dashboard</Link>
                <Link href="/daftar" className="text-gray-600 hover:text-orange-600">Daftar Anak</Link>
                <Link href="/user/profile" className="text-gray-600 hover:text-orange-600">Profil</Link>
              </nav>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-600">Halo, {user?.name}</span>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Keluar
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-800">Selamat Datang, {user?.name}!</h2>
          <p className="text-gray-600">Kelola pendaftaran anak Anda di PAUD Ceria</p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="hover:shadow-md transition-shadow cursor-pointer">
            <Link href="/daftar">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center text-lg">
                  <Plus className="w-5 h-5 mr-2 text-orange-500" />
                  Daftar Anak Baru
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Tambahkan pendaftaran untuk anak lainnya
                </p>
              </CardContent>
            </Link>
          </Card>

          <Card className="hover:shadow-md transition-shadow cursor-pointer">
            <Link href="/user/profile">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center text-lg">
                  <User className="w-5 h-5 mr-2 text-blue-500" />
                  Profil Saya
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Perbarui informasi akun Anda
                </p>
              </CardContent>
            </Link>
          </Card>

          <Card className="hover:shadow-md transition-shadow cursor-pointer">
            <a href="#kontak" className="block">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center text-lg">
                  <Phone className="w-5 h-5 mr-2 text-green-500" />
                  Hubungi Kami
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Butuh bantuan? Hubungi tim kami
                </p>
              </CardContent>
            </a>
          </Card>
        </div>

        {/* Pendaftaran List */}
        <div className="mb-8">
          <h3 className="text-xl font-bold text-gray-800 mb-4">Status Pendaftaran Anak</h3>
          
          {pendaftaranList.length === 0 ? (
            <Card>
              <CardContent className="text-center py-12">
                <Baby className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h4 className="text-lg font-semibold text-gray-600 mb-2">Belum Ada Pendaftaran</h4>
                <p className="text-gray-500 mb-4">
                  Anda belum mendaftarkan anak ke PAUD Ceria
                </p>
                <Link href="/daftar">
                  <Button className="bg-orange-500 hover:bg-orange-600">
                    <Plus className="w-4 h-4 mr-2" />
                    Daftarkan Anak
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              {pendaftaranList.map((pendaftaran) => (
                <Card key={pendaftaran.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-xl">{pendaftaran.siswa.namaLengkap}</CardTitle>
                        <CardDescription className="flex items-center mt-1">
                          <Calendar className="w-4 h-4 mr-1" />
                          Tahun Ajaran {pendaftaran.tahunAjaran}
                        </CardDescription>
                      </div>
                      {getStatusBadge(pendaftaran.status)}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Data Siswa */}
                      <div>
                        <h4 className="font-semibold mb-3 text-gray-700">Data Siswa</h4>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-gray-600">Nama Panggilan:</span>
                            <span className="font-medium">{pendaftaran.siswa.namaPanggilan}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Tanggal Lahir:</span>
                            <span className="font-medium">
                              {new Date(pendaftaran.siswa.tanggalLahir).toLocaleDateString('id-ID')}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Tempat Lahir:</span>
                            <span className="font-medium">{pendaftaran.siswa.tempatLahir}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Jenis Kelamin:</span>
                            <span className="font-medium">
                              {pendaftaran.siswa.jenisKelamin === 'L' ? 'Laki-laki' : 'Perempuan'}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Agama:</span>
                            <span className="font-medium">{pendaftaran.siswa.agama}</span>
                          </div>
                        </div>
                      </div>

                      {/* Data Orang Tua */}
                      <div>
                        <h4 className="font-semibold mb-3 text-gray-700">Data Orang Tua</h4>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-gray-600">Nama Ayah:</span>
                            <span className="font-medium">{pendaftaran.siswa.orangTua.namaAyah}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Nama Ibu:</span>
                            <span className="font-medium">{pendaftaran.siswa.orangTua.namaIbu}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">HP Ayah:</span>
                            <span className="font-medium">{pendaftaran.siswa.orangTua.noHpAyah}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">HP Ibu:</span>
                            <span className="font-medium">{pendaftaran.siswa.orangTua.noHpIbu}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Status Message */}
                    <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                      <p className="text-sm text-gray-700">
                        {getStatusMessage(pendaftaran.status)}
                      </p>
                      {pendaftaran.catatan && (
                        <div className="mt-2">
                          <strong>Catatan:</strong> {pendaftaran.catatan}
                        </div>
                      )}
                    </div>

                    <div className="mt-4 text-sm text-gray-500">
                      <div className="flex justify-between">
                        <span>Tanggal Daftar:</span>
                        <span>{new Date(pendaftaran.tanggalDaftar).toLocaleDateString('id-ID')}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Contact Info */}
        <Card id="kontak">
          <CardHeader>
            <CardTitle>Informasi Kontak</CardTitle>
            <CardDescription>
              Hubungi kami jika Anda memiliki pertanyaan
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-orange-500" />
                <span>(021) 1234-5678</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-orange-500" />
                <span>info@paudceria.sch.id</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
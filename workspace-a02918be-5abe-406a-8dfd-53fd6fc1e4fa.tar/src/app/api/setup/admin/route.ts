import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'

export async function GET() {
  try {
    // Cek apakah admin sudah ada
    const existingAdmin = await db.admin.findFirst({
      where: { email: 'admin@paudceria.sch.id' }
    })

    if (existingAdmin) {
      return NextResponse.json({
        message: 'Admin sudah ada',
        admin: {
          email: existingAdmin.email,
          name: existingAdmin.name
        },
        loginInfo: {
          email: 'admin@paudceria.sch.id',
          password: 'admin123'
        }
      })
    }

    // Hash password
    const hashedPassword = await bcrypt.hash('admin123', 10)

    // Buat admin default
    const admin = await db.admin.create({
      data: {
        email: 'admin@paudceria.sch.id',
        password: hashedPassword,
        name: 'Administrator PAUD Ceria',
        role: 'admin'
      }
    })

    // Response tanpa password
    const { password: _, ...adminWithoutPassword } = admin

    return NextResponse.json({
      message: 'Admin default berhasil dibuat',
      admin: adminWithoutPassword,
      loginInfo: {
        email: 'admin@paudceria.sch.id',
        password: 'admin123'
      }
    })

  } catch (error) {
    console.error('Error creating admin:', error)
    return NextResponse.json(
      { message: 'Terjadi kesalahan server' },
      { status: 500 }
    )
  }
}
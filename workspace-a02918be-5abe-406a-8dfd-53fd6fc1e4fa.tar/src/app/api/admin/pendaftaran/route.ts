import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import jwt from 'jsonwebtoken'

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key'

// Middleware untuk verifikasi token
function verifyToken(request: NextRequest) {
  const authHeader = request.headers.get('authorization')
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null
  }

  const token = authHeader.substring(7)
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as any
    return decoded
  } catch (error) {
    return null
  }
}

// GET - Ambil semua data pendaftaran
export async function GET(request: NextRequest) {
  try {
    const user = verifyToken(request)
    if (!user || user.role !== 'admin') {
      return NextResponse.json(
        { message: 'Unauthorized' },
        { status: 401 }
      )
    }

    const pendaftaran = await db.pendaftaran.findMany({
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true,
            address: true
          }
        },
        siswa: {
          include: {
            orangTua: {
              select: {
                namaAyah: true,
                namaIbu: true,
                noHpAyah: true,
                noHpIbu: true,
                pekerjaanAyah: true,
                pekerjaanIbu: true
              }
            }
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json(pendaftaran)

  } catch (error) {
    console.error('Error fetching pendaftaran:', error)
    return NextResponse.json(
      { message: 'Terjadi kesalahan server' },
      { status: 500 }
    )
  }
}

// PUT - Update status pendaftaran
export async function PUT(request: NextRequest) {
  try {
    const user = verifyToken(request)
    if (!user || user.role !== 'admin') {
      return NextResponse.json(
        { message: 'Unauthorized' },
        { status: 401 }
      )
    }

    const { id, status, catatan } = await request.json()

    if (!id || !status) {
      return NextResponse.json(
        { message: 'ID dan status harus diisi' },
        { status: 400 }
      )
    }

    if (!['menunggu', 'diterima', 'ditolak'].includes(status)) {
      return NextResponse.json(
        { message: 'Status tidak valid' },
        { status: 400 }
      )
    }

    const updatedPendaftaran = await db.pendaftaran.update({
      where: { id },
      data: {
        status,
        catatan: catatan || null
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true
          }
        },
        siswa: {
          include: {
            orangTua: {
              select: {
                namaAyah: true,
                namaIbu: true,
                noHpAyah: true,
                noHpIbu: true
              }
            }
          }
        }
      }
    })

    return NextResponse.json({
      message: 'Status berhasil diperbarui',
      data: updatedPendaftaran
    })

  } catch (error) {
    console.error('Error updating pendaftaran:', error)
    return NextResponse.json(
      { message: 'Terjadi kesalahan server' },
      { status: 500 }
    )
  }
}
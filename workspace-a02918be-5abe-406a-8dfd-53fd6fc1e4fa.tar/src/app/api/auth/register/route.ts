import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    // Validasi required fields
    const requiredFields = ['name', 'email', 'password', 'namaAyah', 'namaIbu', 'namaLengkap', 'tanggalLahir', 'jenisKelamin']
    for (const field of requiredFields) {
      if (!data[field]) {
        return NextResponse.json(
          { message: `Field ${field} harus diisi` },
          { status: 400 }
        )
      }
    }

    // Validasi password match
    if (data.password !== data.confirmPassword) {
      return NextResponse.json(
        { message: 'Password dan konfirmasi password harus sama' },
        { status: 400 }
      )
    }

    // Cek apakah email sudah terdaftar
    const existingUser = await db.user.findUnique({
      where: { email: data.email }
    })

    if (existingUser) {
      return NextResponse.json(
        { message: 'Email sudah terdaftar' },
        { status: 400 }
      )
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(data.password, 10)

    // Buat user baru
    const user = await db.user.create({
      data: {
        name: data.name,
        email: data.email,
        password: hashedPassword,
        phone: data.phone || '',
        address: data.address || ''
      }
    })

    // Buat data orang tua
    const orangTua = await db.orangTua.create({
      data: {
        userId: user.id,
        namaAyah: data.namaAyah,
        namaIbu: data.namaIbu,
        pekerjaanAyah: data.pekerjaanAyah || '',
        pekerjaanIbu: data.pekerjaanIbu || '',
        noHpAyah: data.noHpAyah,
        noHpIbu: data.noHpIbu,
        alamat: data.address || ''
      }
    })

    // Buat data siswa
    const siswa = await db.siswa.create({
      data: {
        orangTuaId: orangTua.id,
        namaLengkap: data.namaLengkap,
        namaPanggilan: data.namaPanggilan || data.namaLengkap,
        tempatLahir: data.tempatLahir || '',
        tanggalLahir: new Date(data.tanggalLahir),
        jenisKelamin: data.jenisKelamin,
        agama: data.agama || '',
        anakKe: data.anakKe ? parseInt(data.anakKe) : null,
        jumlahSaudara: data.jumlahSaudara ? parseInt(data.jumlahSaudara) : null,
        bahasaRumah: data.bahasaRumah || '',
        alamat: data.address || ''
      }
    })

    // Buat data pendaftaran
    const pendaftaran = await db.pendaftaran.create({
      data: {
        userId: user.id,
        siswaId: siswa.id,
        tahunAjaran: data.tahunAjaran || '2024/2025',
        status: 'menunggu'
      }
    })

    // Response tanpa password
    const { password: _, ...userWithoutPassword } = user

    return NextResponse.json({
      message: 'Pendaftaran berhasil! Silakan login untuk melanjutkan.',
      user: userWithoutPassword,
      orangTua,
      siswa,
      pendaftaran
    })

  } catch (error) {
    console.error('Registration error:', error)
    return NextResponse.json(
      { message: 'Terjadi kesalahan server' },
      { status: 500 }
    )
  }
}
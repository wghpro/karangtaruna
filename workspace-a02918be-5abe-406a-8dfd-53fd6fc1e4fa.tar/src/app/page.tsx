'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  Baby, 
  Users, 
  BookOpen, 
  Heart, 
  Star, 
  Clock, 
  MapPin,
  Phone,
  Mail,
  Award,
  Palette,
  Music,
  Gamepad2
} from 'lucide-react'

export default function Home() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-pink-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center">
                <Baby className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-orange-600">PAUD Ceria</h1>
            </div>
            
            <nav className="hidden md:flex space-x-6">
              <a href="#beranda" className="text-gray-700 hover:text-orange-600 transition">Beranda</a>
              <a href="#tentang" className="text-gray-700 hover:text-orange-600 transition">Tentang</a>
              <a href="#program" className="text-gray-700 hover:text-orange-600 transition">Program</a>
              <a href="#fasilitas" className="text-gray-700 hover:text-orange-600 transition">Fasilitas</a>
              <a href="#kontak" className="text-gray-700 hover:text-orange-600 transition">Kontak</a>
            </nav>

            <div className="flex space-x-2">
              <Link href="/login">
                <Button variant="outline" size="sm">Masuk</Button>
              </Link>
              <Link href="/daftar">
                <Button size="sm">Daftar Sekarang</Button>
              </Link>
            </div>

            <Button 
              variant="ghost" 
              size="sm"
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              ☰
            </Button>
          </div>

          {isMenuOpen && (
            <nav className="md:hidden mt-4 space-y-2">
              <a href="#beranda" className="block py-2 text-gray-700 hover:text-orange-600">Beranda</a>
              <a href="#tentang" className="block py-2 text-gray-700 hover:text-orange-600">Tentang</a>
              <a href="#program" className="block py-2 text-gray-700 hover:text-orange-600">Program</a>
              <a href="#fasilitas" className="block py-2 text-gray-700 hover:text-orange-600">Fasilitas</a>
              <a href="#kontak" className="block py-2 text-gray-700 hover:text-orange-600">Kontak</a>
            </nav>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section id="beranda" className="py-20 px-4">
        <div className="container mx-auto text-center">
          <div className="mb-8">
            <div className="w-24 h-24 bg-orange-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <Baby className="w-16 h-16 text-white" />
            </div>
          </div>
          <h2 className="text-5xl font-bold text-gray-800 mb-6">
            Selamat Datang di <span className="text-orange-500">PAUD Ceria</span>
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Membangun fondasi kuat untuk masa depan cerah anak-anak Indonesia melalui pendidikan usia dini yang berkualitas dan penuh kasih sayang.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/daftar">
              <Button size="lg" className="bg-orange-500 hover:bg-orange-600">
                Daftarkan Anak Anda
              </Button>
            </Link>
            <Link href="#tentang">
              <Button variant="outline" size="lg">
                Pelajari Lebih Lanjut
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-orange-500 mb-2">150+</div>
              <div className="text-gray-600">Siswa Aktif</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-orange-500 mb-2">20+</div>
              <div className="text-gray-600">Pengajar Profesional</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-orange-500 mb-2">10+</div>
              <div className="text-gray-600">Tahun Pengalaman</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-orange-500 mb-2">98%</div>
              <div className="text-gray-600">Kepuasan Orang Tua</div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="tentang" className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-800 mb-4">Tentang PAUD Ceria</h3>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Kami adalah lembaga pendidikan anak usia dini yang berkomitmen untuk memberikan pendidikan berkualitas 
              dengan pendekatan yang menyenangkan dan sesuai dengan tahap perkembangan anak.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardHeader>
                <Heart className="w-12 h-12 text-red-500 mx-auto mb-4" />
                <CardTitle>Penuh Kasih</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Lingkungan yang penuh kasih sayang dan perhatian untuk setiap anak
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <BookOpen className="w-12 h-12 text-blue-500 mx-auto mb-4" />
                <CardTitle>Berkualitas</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Kurikulum yang terstruktur dan sesuai standar pendidikan nasional
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <Star className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
                <CardTitle>Inovatif</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Metode pembelajaran kreatif dan berbasis aktivitas yang menyenangkan
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Programs Section */}
      <section id="program" className="py-20 px-4 bg-white">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-800 mb-4">Program Unggulan</h3>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Berbagai program yang dirancang khusus untuk mendukung tumbuh kembang anak usia dini
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <div className="flex items-center space-x-2 mb-2">
                  <Baby className="w-6 h-6 text-orange-500" />
                  <Badge variant="secondary">KB</Badge>
                </div>
                <CardTitle>Kelompok Bermain (2-3 Tahun)</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  Perkenalan dasar sosialisasi, motorik halus, dan pengenalan lingkungan
                </p>
                <ul className="text-sm text-gray-500 space-y-1">
                  <li>• Stimulasi sensorik</li>
                  <li>• Permainan edukatif</li>
                  <li>• Kegiatan seni dan kreativitas</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center space-x-2 mb-2">
                  <Users className="w-6 h-6 text-blue-500" />
                  <Badge variant="secondary">TK A</Badge>
                </div>
                <CardTitle>Taman Kanak-Kanak A (3-4 Tahun)</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  Pengembangan sosial, emosional, dan kognitif yang lebih terstruktur
                </p>
                <ul className="text-sm text-gray-500 space-y-1">
                  <li>• Pengenalan huruf dan angka</li>
                  <li>• Pembiasaan disiplin</li>
                  <li>• Kegiatan kelompok</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center space-x-2 mb-2">
                  <Award className="w-6 h-6 text-green-500" />
                  <Badge variant="secondary">TK B</Badge>
                </div>
                <CardTitle>Taman Kanak-Kanak B (4-6 Tahun)</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  Persiapan memasuki sekolah dasar dengan pembelajaran komprehensif
                </p>
                <ul className="text-sm text-gray-500 space-y-1">
                  <li>• Membaca dan menulis dasar</li>
                  <li>• Berhitung dan logika</li>
                  <li>• Kesiapan sekolah</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Facilities Section */}
      <section id="fasilitas" className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-800 mb-4">Fasilitas Lengkap</h3>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Fasilitas modern dan aman untuk mendukung proses pembelajaran yang optimal
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center">
              <CardHeader>
                <Palette className="w-12 h-12 text-purple-500 mx-auto mb-2" />
                <CardTitle className="text-lg">Ruang Seni</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">Ruang kreativitas dengan peralatan seni lengkap</p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <Gamepad2 className="w-12 h-12 text-green-500 mx-auto mb-2" />
                <CardTitle className="text-lg">Area Bermain</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">Taman bermain outdoor dan indoor yang aman</p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <Music className="w-12 h-12 text-pink-500 mx-auto mb-2" />
                <CardTitle className="text-lg">Ruang Musik</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">Alat musik edukatif untuk stimulasi audio</p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <BookOpen className="w-12 h-12 text-blue-500 mx-auto mb-2" />
                <CardTitle className="text-lg">Perpustakaan Mini</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">Buku cerita dan edukasi anak usia dini</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="kontak" className="py-20 px-4 bg-white">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-800 mb-4">Hubungi Kami</h3>
            <p className="text-gray-600">Siap membantu Anda memberikan yang terbaik untuk buah hati</p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 max-w-4xl mx-auto">
            <div>
              <h4 className="text-xl font-semibold mb-6">Informasi Kontak</h4>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <MapPin className="w-5 h-5 text-orange-500" />
                  <span className="text-gray-600">Jl. Pendidikan No. 123, Jakarta Selatan</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Phone className="w-5 h-5 text-orange-500" />
                  <span className="text-gray-600">(021) 1234-5678</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Mail className="w-5 h-5 text-orange-500" />
                  <span className="text-gray-600">info@paudceria.sch.id</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Clock className="w-5 h-5 text-orange-500" />
                  <span className="text-gray-600">Senin - Jumat: 07:00 - 12:00</span>
                </div>
              </div>
            </div>

            <div>
              <h4 className="text-xl font-semibold mb-6">Jam Operasional</h4>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Senin - Kamis</span>
                  <span className="font-medium">07:00 - 12:00</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Jumat</span>
                  <span className="font-medium">07:00 - 11:30</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Sabtu - Minggu</span>
                  <span className="font-medium text-red-500">Libur</span>
                </div>
              </div>
              
              <div className="mt-6">
                <Link href="/daftar">
                  <Button className="w-full bg-orange-500 hover:bg-orange-600">
                    Daftar Sekarang
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 px-4">
        <div className="container mx-auto text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
              <Baby className="w-5 h-5 text-white" />
            </div>
            <h4 className="text-xl font-bold">PAUD Ceria</h4>
          </div>
          <p className="text-gray-400 mb-4">
            Membangun generasi ceria dan cerdas sejak dini
          </p>
          <p className="text-sm text-gray-500">
            © 2024 PAUD Ceria. Hak Cipta Dilindungi.
          </p>
        </div>
      </footer>
    </div>
  )
}
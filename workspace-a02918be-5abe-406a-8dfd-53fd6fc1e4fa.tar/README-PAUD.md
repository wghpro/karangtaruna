# Sistem Informasi Pendaftaran PAUD Ceria

Website pendaftaran sekolah anak usia dini (PAUD) yang modern dan lengkap dengan hak akses admin dan user pendaftar.

## Fitur Utama

### 🔐 Sistem Autentikasi
- Login untuk Admin dan User (Orang Tua/Wali)
- Password hashing dengan bcryptjs
- JWT token untuk session management

### 📝 Pendaftaran Siswa
- Form pendaftaran multi-step (4 langkah)
- Data lengkap siswa, orang tua, dan pendaftaran
- Validasi input yang komprehensif

### 👨‍💼 Dashboard Admin
- Lihat semua data pendaftaran
- Filter dan pencarian data
- Update status (menunggu/diterima/ditolak)
- Statistik pendaftaran real-time

### 👨‍👩‍👧 Dashboard User
- Lihat status pendaftaran anak
- Detail lengkap data siswa dan orang tua
- Informasi kontak PAUD

### 🎨 Desain Modern
- Responsive design untuk mobile dan desktop
- Komponen shadcn/ui yang modern
- Warna tema orange yang ceria
- Animasi dan transisi yang smooth

## Cara Memulai

### 1. Setup Admin Default
Buka browser dan akses:
```
http://localhost:3000/api/setup/admin
```
Ini akan membuat admin default dengan:
- Email: `admin@paudceria.sch.id`
- Password: `admin123`

### 2. Login sebagai Admin
1. Buka `http://localhost:3000/login`
2. Pilih "Administrator"
3. Masukkan email dan password admin
4. Anda akan diarahkan ke dashboard admin

### 3. Daftar sebagai User Baru
1. Buka `http://localhost:3000/daftar`
2. Isi formulir pendaftaran multi-step:
   - **Step 1**: Data akun (nama, email, password)
   - **Step 2**: Data orang tua/wali
   - **Step 3**: Data calon siswa
   - **Step 4**: Konfirmasi dan persetujuan
3. Setelah selesai, login dengan akun yang dibuat

### 4. Akses Dashboard User
Setelah login, user dapat:
- Melihat status pendaftaran anak
- Melihat detail lengkap data
- Mendaftarkan anak lainnya
- Menghubungi admin

## Struktur Database

### Tables:
- **Admin**: Data administrator sistem
- **User**: Data orang tua/wali yang mendaftar
- **OrangTua**: Data lengkap orang tua siswa
- **Siswa**: Data calon siswa PAUD
- **Pendaftaran**: Data pendaftaran dengan status tracking

### Relationships:
- User → OrangTua (1:N)
- OrangTua → Siswa (1:N)
- User → Pendaftaran (1:N)
- Siswa → Pendaftaran (1:N)

## API Endpoints

### Authentication
- `POST /api/auth/login` - Login user/admin
- `POST /api/auth/register` - Registrasi user baru

### Admin
- `GET /api/admin/pendaftaran` - Ambil semua data pendaftaran
- `PUT /api/admin/pendaftaran/[id]` - Update status pendaftaran

### User
- `GET /api/user/pendaftaran` - Ambil data pendaftaran user

### Setup
- `GET /api/setup/admin` - Setup admin default

## Teknologi

- **Frontend**: Next.js 15, React 19, TypeScript 5
- **Backend**: Next.js API Routes, Prisma ORM
- **Database**: SQLite
- **Styling**: Tailwind CSS, shadcn/ui
- **Authentication**: JWT, bcryptjs
- **Icons**: Lucide React

## Cara Menjalankan

1. Install dependencies:
```bash
npm install
```

2. Setup database:
```bash
npm run db:push
```

3. Jalankan development server:
```bash
npm run dev
```

4. Buka browser di `http://localhost:3000`

## Default Credentials

### Admin:
- Email: `admin@paudceria.sch.id`
- Password: `admin123`

### User:
- Register melalui halaman `/daftar`

## Catatan

- Pastikan untuk setup admin default terlebih dahulu
- User dapat mendaftar langsung tanpa persetujuan admin
- Admin dapat melihat dan mengelola semua pendaftaran
- Status pendaftaran: menunggu → diterima/ditolak
- Sistem menggunakan localStorage untuk menyimpan token

## Support

Jika ada masalah atau pertanyaan, hubungi tim development PAUD Ceria.